import React, { Component } from 'react';
import STATE from "./State";
import { withRouter } from "react-router-dom";
import { connect } from 'react-redux';
import { updateQuestion } from "./js/actions/questionPaper-action";


class WorkArea extends Component {
    constructor(props) {
        super(props);
        this.state = STATE;
    }  // constructor
    render() {
        console.log('Inside WorkArea ');
        return (
            <div className="col-lg-6 panel panel-info">
            <div style={{backgroundColor: 'yellow'}} >
                <h2>{this.state.datatext.workarea}</h2>
                <h2>{this.props.questionPaper}</h2>
            </div>
         </div>
        );
    }
}
function mapStateToProps(state) {
    console.log('state*******************',state); // state
    console.log(arguments[1]); // undefined
    return {
      questionPaper:state.questionPaperReducer,
      user:state.adminReducer
    }
  }
  const mapActionsToProps = state => ({
    onUpdateQuestion: updateQuestion
  });
export default connect(mapStateToProps, mapActionsToProps)(WorkArea);

