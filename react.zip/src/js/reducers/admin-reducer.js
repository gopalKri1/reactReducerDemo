export default function adminReducer(state = "", {type, payload}) {
  // console.log(action);
  return state;
  }
