export const UPDATE_QUESTION = "UPDATE_QUESTION";
export const ADD_QUESTION = "ADD_QUESTION";
//export const ADD_ARTICLE = "ADD_ARTICLE";
